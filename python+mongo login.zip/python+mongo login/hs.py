import hashlib

password = input("Enter String to hash: ")
pass_hash= hashlib.md5(password.encode()).hexdigest()
print(pass_hash)

