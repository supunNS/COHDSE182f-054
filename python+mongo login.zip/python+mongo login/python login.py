import hashlib
import pymongo


print("\033[2;30;47m Enter Username here : ")

user = input()


print("\033[1;31;40m Enter your password here : ")

passw = input()
hashedpw = hashlib.md5(passw.encode())
hpassw = (hashedpw.hexdigest())

try:
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")
    mydb = myclient["companydb"]
    mycol = mydb["userlog"]
    det = mycol.find({})
    myclient.close()
    for x in det:
        print(x['password'])
        if user == x['username'] and hpassw == x['password']:
            print("logged in successfully")
        else:
            print("incorrect password OR username")

except Exception:
    print("some error occured, try later ")
    print("try one of these : \n 1) check your database connectiion \n 2) queries doesn't match \n 3) contact your developer")



















